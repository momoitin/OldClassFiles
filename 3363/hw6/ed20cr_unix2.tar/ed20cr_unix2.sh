diff -w -i text1.txt text2.txt

grep -i ^the text1.txt text2.txt; grep -i 'ee' text1.txt text2.txt

ps -l -e >> ed20cr_processes.txt

tar -cf ed20cr_unix2.tar ed20cr_unix2.sh ed20cr_output.txt ed20cr_processes.txt